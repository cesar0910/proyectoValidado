/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.com.tsys.ecd.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Excepcion que cacha y trata los servicios que se bloquean
 * @author Viera Rebolledo Jose B.  -   jviera.dev@gmail.com
 * @since Julio 2015
 * @version 1.0
 */
@ResponseStatus(value = HttpStatus.LOCKED, reason = "El servicio se encuentra bloqueado.")
public class LockedException extends RuntimeException {

    public LockedException() {
    }

    public LockedException(String message) {
        super(message);
    }

    public LockedException(String message, Throwable cause) {
        super(message, cause);
    }

    public LockedException(Throwable cause) {
        super(cause);
    }    
    
}
