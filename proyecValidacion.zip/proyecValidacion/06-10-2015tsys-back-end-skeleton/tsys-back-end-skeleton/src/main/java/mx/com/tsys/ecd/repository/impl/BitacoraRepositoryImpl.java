/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.com.tsys.ecd.repository.impl;

import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import mx.com.tsys.ecd.entity.BitacoraEntity;
import mx.com.tsys.ecd.entity.CatalogoAccionEntity;
import mx.com.tsys.ecd.entity.TarjetaHabienteEntity;
import mx.com.tsys.ecd.repository.BitacoraRepositoryCustom;
import org.springframework.transaction.annotation.Transactional;

/**
 * implementacion de repositorio custom
 *
 * @since 01/09/2015
 * @version 1.0
 * @author Said Guerrero
 */
public class BitacoraRepositoryImpl implements BitacoraRepositoryCustom {

    @PersistenceContext
    private EntityManager em;
    private Object calendar;
  

    /**
     * Configure the entity manager to be used.
     *
     * @param em the {@link EntityManager} to set.
     */
    public void setEntityManager(EntityManager em) {
        this.em = em;
    }

    /**
     * Metodo que recibe los componentes individuales del entity y los persiste
     *
     * @param tarjetaHabienteEntity
     * @param catalogoAccionEntity
     * @param idError
     * @param detalleAccion
     * @return
     */
    
    
    
    @Override
    @Transactional
    public BitacoraEntity guardaBitacora(TarjetaHabienteEntity tarjetaHabienteEntity, CatalogoAccionEntity catalogoAccionEntity, String idError, String detalleAccion, HttpServletRequest request) {
      
       
        BitacoraEntity entity = new BitacoraEntity();
        entity.setNoCuenta(tarjetaHabienteEntity);
        entity.setIdAccion(catalogoAccionEntity);
        entity.setFecha(new Date());
        entity.setIdError(idError);
        entity.setDetalleAccion(detalleAccion);
        // IP del cliente
        entity.setDireccionIp(request.getRemoteAddr());
        
        // Navegador
        entity.setNavegador(request.getHeader("User-Agent"));
       
        
        String string = getRegion(request);
        String[] parts = string.split("/");
        String part1 = parts[0]; 
        String part2 = parts[1]; 
        
        
        // Obtener Region
        entity.setRegion(part2);
        //Obtener ZonaHoraria       
        entity.setZonaHoraria(part1);
        
       
        return em.merge(entity);
        
       
    }
    
    private String getRegion(HttpServletRequest request) {
        Locale clientLocale = request.getLocale();
        Calendar calendar = Calendar.getInstance(clientLocale);
        
        TimeZone clientTimeZone = calendar.getTimeZone();
        return clientTimeZone.getID();
        
    }

}
