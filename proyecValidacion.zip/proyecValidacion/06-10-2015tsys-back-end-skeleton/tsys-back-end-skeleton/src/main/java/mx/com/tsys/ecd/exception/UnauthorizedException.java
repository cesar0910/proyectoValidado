/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.com.tsys.ecd.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Clase que cacha y trata las excepciones generadas por accesos no autorizados
 * @author Viera Rebolledo Jose B.  -   jviera.dev@gmail.com
 * @since Julio 2015
 * @version 1.0
 */
@ResponseStatus(value = HttpStatus.UNAUTHORIZED, reason = "No se encuentra autorizado para solicitar el servicio.")
public class UnauthorizedException extends RuntimeException {

    public UnauthorizedException() {
    }

    public UnauthorizedException(String message) {
        super(message);
    }

    public UnauthorizedException(String message, Throwable cause) {
        super(message, cause);
    }

    public UnauthorizedException(Throwable cause) {
        super(cause);
    }   
    
}
