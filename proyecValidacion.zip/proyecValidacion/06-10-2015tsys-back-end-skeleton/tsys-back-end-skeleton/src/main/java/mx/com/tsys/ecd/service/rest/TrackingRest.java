/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.com.tsys.ecd.service.rest;

import java.util.Date;
import javax.servlet.http.HttpServletRequest;
import mx.com.tsys.ecd.common.CommonUtils;
import mx.com.tsys.ecd.common.Constantes;
import mx.com.tsys.ecd.common.StackTraceUtil;
import mx.com.tsys.ecd.common.SystemProperties;
import mx.com.tsys.ecd.entity.CatalogoAccionEntity;
import mx.com.tsys.ecd.entity.EstadoCuentaEntity;
import mx.com.tsys.ecd.entity.TarjetaHabienteEntity;
import mx.com.tsys.ecd.entity.TrackingEntity;
import mx.com.tsys.ecd.exception.InternalServerErrorExcepcion;
import mx.com.tsys.ecd.exception.InvalidInputDataException;
import mx.com.tsys.ecd.exception.UnauthorizedException;
import mx.com.tsys.ecd.repository.BitacoraRepository;
import mx.com.tsys.ecd.repository.EstadoCuentaRepository;
import mx.com.tsys.ecd.repository.TrackingRepository;
import mx.com.tsys.ecd.repository.CatalogoAccionRepository;
import mx.com.tsys.ecd.repository.TarjetaHabienteRepository;
import org.apache.logging.log4j.LogManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.view.RedirectView;

/**
 * Clase que expone los servicios Rest
 *
 * @since septiembre 2015
 * @version 1.0
 * @author Cesar Ruiz
 */
@RestController
@RequestMapping("/rest")
public class TrackingRest {

    //Lleva la bitacora de logs segun la configuracion del archivo log4j2.xml
    private static final org.apache.logging.log4j.Logger log = LogManager.getLogger(TrackingRest.class.getName());

    @Autowired
    private EstadoCuentaRepository estadoCuentaRepository;

    @Autowired
    private TrackingRepository trackingRepository;

    @Autowired
    private TarjetaHabienteRepository tarjetaHabienteRepository;

    @Autowired
    private BitacoraRepository bitacoraRepository;

    @Autowired
    private CatalogoAccionRepository catalogoAccionRepository;

    /**
     *servicio que almacena en que promocion
     * dio click el cliente 
     * @param noCuenta
     * @param detalle
     * @param url
     * @return
     */
    @RequestMapping(value = "/trk/{noCuenta}/{detalle}/{url}", method = RequestMethod.GET)
    @ResponseBody
    public RedirectView tracking(@PathVariable("noCuenta") String noCuenta, @PathVariable("detalle") String detalle, @PathVariable("url") String url, HttpServletRequest request) {
        boolean success = false;
        String mensaje = "OK";
        String noCuentaTmp="";
        try {
            log.info("Solicitud Tracking...");
            if (CommonUtils.isEmpty(noCuenta) || CommonUtils.isEmpty(detalle) || CommonUtils.isEmpty(url)) {
                log.info("no Cuenta/id tracking is null.");
                mensaje = "no Cuenta/id tracking/detalle / url is null.";
                throw new InvalidInputDataException("no Cuenta/id tracking/detalle / url is null.");
            } else {

                EstadoCuentaEntity estadoCuentaEntity = estadoCuentaRepository.findByNoCuenta(noCuenta);

                if (estadoCuentaEntity != null) {
                    //guarda en trk
                    noCuentaTmp=estadoCuentaEntity.getNoCuenta().getNoCuenta();
                    TrackingEntity trackingEntity = new TrackingEntity();
                    trackingEntity.setFecha(new Date());
                    trackingEntity.setDetalle(detalle);
                    trackingEntity.setUrl(url);
                    trackingEntity.setIdEstadoCuenta(estadoCuentaEntity);
                    trackingRepository.save(trackingEntity);
                    success = true;
                }
               
            }

            return success ? new RedirectView(SystemProperties.getPropertyClassPath(Constantes.PAGE_SUCCESS), true)
                    : new RedirectView(SystemProperties.getPropertyClassPath(Constantes.PAGE_ALREADY_EXIST), true);
        } catch (InvalidInputDataException e) {
            log.error(StackTraceUtil.getStackTrace(e));
            throw new InvalidInputDataException(e.getMessage());
        } catch (UnauthorizedException e) {
            log.error(StackTraceUtil.getStackTrace(e));
            throw new UnauthorizedException(e.getMessage());
        } catch (Exception e) {
            log.error(StackTraceUtil.getStackTrace(e));
            mensaje = "Se genero un error interno.";
            throw new InternalServerErrorExcepcion("Se genero un error interno.");
        } finally {
            TarjetaHabienteEntity tarjetaHabienteEntity = (CommonUtils.isEmpty(noCuentaTmp))
                    ? null : tarjetaHabienteRepository.findOne(noCuentaTmp);
            CatalogoAccionEntity catalogoAccionEntity = catalogoAccionRepository.findOne(Constantes.ID_ACCION_TRK);
            bitacoraRepository.guardaBitacora(tarjetaHabienteEntity, catalogoAccionEntity, success ? Constantes.CODIGO_OK : Constantes.CODIGO_ERROR, mensaje, request);
        }
    }

}
