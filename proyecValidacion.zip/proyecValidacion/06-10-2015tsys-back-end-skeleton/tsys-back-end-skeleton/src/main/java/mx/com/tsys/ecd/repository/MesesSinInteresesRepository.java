/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.com.tsys.ecd.repository;

import mx.com.tsys.ecd.entity.MesesSinInteresesEntity;
import org.springframework.data.repository.CrudRepository;

/**
 * repositorio
 *
 * @since septiembre 2015
 * @version 1.0
 * @author Said Guerrero
 */
public interface MesesSinInteresesRepository extends CrudRepository<MesesSinInteresesEntity, String> {

}
