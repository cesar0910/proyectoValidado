/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.com.tsys.ecd.entity;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size; 

/** clase entity
 * @since septiembre 2015
 * @version 1.0
 * @author Said Guerrero
 */
@Entity
@Table(name = "BANCO")
public class BancoEntity implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "RFC")
    private String rfc;
    @Size(max = 100)
    @Column(name = "NOMBRE")
    private String nombre;
    @Size(max = 100)
    @Column(name = "RAZON_SOCIAL")
    private String razonSocial;
    @OneToMany(mappedBy = "rfcBanco")
    private List<TarjetaHabienteEntity> tarjetaHabienteEntityList;

    public BancoEntity() {
    }

    public BancoEntity(String rfc) {
        this.rfc = rfc;
    }

    public String getRfc() {
        return rfc;
    }

    public void setRfc(String rfc) {
        this.rfc = rfc;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getRazonSocial() {
        return razonSocial;
    }

    public void setRazonSocial(String razonSocial) {
        this.razonSocial = razonSocial;
    }

    public List<TarjetaHabienteEntity> getTarjetaHabienteEntityList() {
        return tarjetaHabienteEntityList;
    }

    public void setTarjetaHabienteEntityList(List<TarjetaHabienteEntity> tarjetaHabienteEntityList) {
        this.tarjetaHabienteEntityList = tarjetaHabienteEntityList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (rfc != null ? rfc.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof BancoEntity)) {
            return false;
        }
        BancoEntity other = (BancoEntity) object;
        if (  !this.rfc.equals(other.rfc)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "mx.com.tsys.ws.entity.BancoEntity[ rfc=" + rfc + " ]";
    }
    
}
