 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.com.tsys.ecd.repository;

import javax.servlet.http.HttpServletRequest;
import mx.com.tsys.ecd.entity.BitacoraEntity;
import mx.com.tsys.ecd.entity.CatalogoAccionEntity;
import mx.com.tsys.ecd.entity.TarjetaHabienteEntity;

/**repositorio Custom que contine metodo de guardado
 * @since septiembre 2015
 * @version 1.0
 * @author Said Guerrero
 */
public interface BitacoraRepositoryCustom {
    
   /**
    * Metodo que recibe los componentes individuales del entity y los persiste
    * @param tarjetaHabienteEntity
    * @param catalogoAccionEntity
    * @param idError
    * @param detalleAccion
    * @param request peticion del usuario
    * @return 
    */
   public BitacoraEntity guardaBitacora( TarjetaHabienteEntity tarjetaHabienteEntity , CatalogoAccionEntity catalogoAccionEntity, String idError, String detalleAccion, HttpServletRequest request);
   
}
