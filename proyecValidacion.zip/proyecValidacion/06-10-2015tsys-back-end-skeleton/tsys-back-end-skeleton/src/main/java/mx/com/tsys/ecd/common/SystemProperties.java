/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.com.tsys.ecd.common;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

/**
 * Propiedades del sistema a patir de un archivo properties
 *
 * @author Viera Rebolledo Jose B.
 * @since Junio 2015
 * @version 1.0
 */
public final class SystemProperties {

    public static Properties propClasspath = null;
    public static Properties propFileSystem = null;

    //Se declara privado para no permitir la creacion de nuevas instancias
    private SystemProperties() {
    }

    public static Properties getPropClasspath() {
         if (null == propClasspath) {
            propClasspath = new Properties();
            try {
                propClasspath.load(SystemProperties.class.getClassLoader().getResourceAsStream(Constantes.PROPERTIES_CLASS_PATH));
            } catch (IOException ioe) {
                throw new RuntimeException("Error al leer el archivo de propiedades a partir de la ruta: "+Constantes.PROPERTIES_CLASS_PATH);
            }
        }
        return propClasspath;
    }

    public static Properties getPropFileSystem() {
        if (null == propFileSystem) {
            propFileSystem = new Properties();
            try {
                propFileSystem.load(new FileInputStream(Constantes.PROPERTIES_FILE_SYSTEM));
            } catch (IOException ioe) {
                throw new RuntimeException("Error al leer el archivo de propiedades a partir de la ruta: "+Constantes.PROPERTIES_FILE_SYSTEM);
            }
        }
        return propFileSystem;
    }    
    
    /**
     * Load a properties file from the file system and retrieved the property value.
     * @param key
     * @return 
     */
    public static String getPropertyFileSystem(String key) {
        if (null == propFileSystem) {
            propFileSystem = new Properties();
            try {
                propFileSystem.load(new FileInputStream(Constantes.PROPERTIES_FILE_SYSTEM));
            } catch (IOException ioe) {
                throw new RuntimeException("Error al leer el archivo de propiedades a partir de la ruta: "+Constantes.PROPERTIES_FILE_SYSTEM);
            }
        }
        return propFileSystem.getProperty(key);
    }
    
    /**
     * Load a properties file from classpath
     * @param key
     * @return 
     */
    public static String getPropertyClassPath(String key) {
        if (null == propClasspath) {
            propClasspath = new Properties();
            try {
                propClasspath.load(SystemProperties.class.getClassLoader().getResourceAsStream(Constantes.PROPERTIES_CLASS_PATH));
            } catch (IOException ioe) {
                throw new RuntimeException("Error al leer el archivo de propiedades a partir de la ruta: "+Constantes.PROPERTIES_CLASS_PATH);
            }
        }
        return propClasspath.getProperty(key);
    }
}
