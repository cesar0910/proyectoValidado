/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.com.tsys.ecd.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * clase entity
 *
 * @since septiembre 2015
 * @version 1.0
 * @author Said Guerrero
 */
@Entity
@Table(name = "ESTADO_CUENTA")
public class EstadoCuentaEntity implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 30)
    @Column(name = "ID_ESTADO_CUENTA")
    private String idEstadoCuenta;
    @Column(name = "FECHA_CORTE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date fechaCorte;
    @Lob
    @Column(name = "ECD")
    private byte[] ecd;
    @Size(max = 50)
    @Column(name = "NOMENCLATURA_HTML")
    private String nomenclaturaHtml;
    @Lob
    @Column(name = "PDF")
    private byte[] pdf;
    @Size(max = 50)
    @Column(name = "NOMENCLATURA_PDF")
    private String nomenclaturaPdf;
    @Lob
    @Column(name = "PDFL")
    private byte[] pdfl;
    @JoinColumn(name = "NO_CUENTA", referencedColumnName = "NO_CUENTA")
    @ManyToOne
    private TarjetaHabienteEntity noCuenta;
    @OneToMany(mappedBy = "idEstadoCuenta")
    private List<CargosNoReconocidosEntity> cargosNoReconocidosEntityList;
    @OneToMany(mappedBy = "idEstadoCuenta")
    private List<MesesSinInteresesEntity> mesesSinInteresesEntityList;

    public EstadoCuentaEntity() {
    }

    public EstadoCuentaEntity(String idEstadoCuenta) {
        this.idEstadoCuenta = idEstadoCuenta;
    }

    public String getIdEstadoCuenta() {
        return idEstadoCuenta;
    }

    public void setIdEstadoCuenta(String idEstadoCuenta) {
        this.idEstadoCuenta = idEstadoCuenta;
    }

    public Date getFechaCorte() {
        return fechaCorte;
    }

    public void setFechaCorte(Date fechaCorte) {
        this.fechaCorte = fechaCorte;
    }

    public String getNomenclaturaHtml() {
        return nomenclaturaHtml;
    }

    public void setNomenclaturaHtml(String nomenclaturaHtml) {
        this.nomenclaturaHtml = nomenclaturaHtml;
    }


    public String getNomenclaturaPdf() {
        return nomenclaturaPdf;
    }

    public void setNomenclaturaPdf(String nomenclaturaPdf) {
        this.nomenclaturaPdf = nomenclaturaPdf;
    }

    public byte[] getEcd() {
        return ecd;
    }

    public void setEcd(byte[] ecd) {
        this.ecd = ecd;
    }

    public byte[] getPdf() {
        return pdf;
    }

    public void setPdf(byte[] pdf) {
        this.pdf = pdf;
    }

    public byte[] getPdfl() {
        return pdfl;
    }

    public void setPdfl(byte[] pdfl) {
        this.pdfl = pdfl;
    }

   

    public TarjetaHabienteEntity getNoCuenta() {
        return noCuenta;
    }

    public void setNoCuenta(TarjetaHabienteEntity noCuenta) {
        this.noCuenta = noCuenta;
    }

    public List<CargosNoReconocidosEntity> getCargosNoReconocidosEntityList() {
        return cargosNoReconocidosEntityList;
    }

    public void setCargosNoReconocidosEntityList(List<CargosNoReconocidosEntity> cargosNoReconocidosEntityList) {
        this.cargosNoReconocidosEntityList = cargosNoReconocidosEntityList;
    }

    public List<MesesSinInteresesEntity> getMesesSinInteresesEntityList() {
        return mesesSinInteresesEntityList;
    }

    public void setMesesSinInteresesEntityList(List<MesesSinInteresesEntity> mesesSinInteresesEntityList) {
        this.mesesSinInteresesEntityList = mesesSinInteresesEntityList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idEstadoCuenta != null ? idEstadoCuenta.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof EstadoCuentaEntity)) {
            return false;
        }
        EstadoCuentaEntity other = (EstadoCuentaEntity) object;
        if ((this.idEstadoCuenta == null && other.idEstadoCuenta != null) || (this.idEstadoCuenta != null && !this.idEstadoCuenta.equals(other.idEstadoCuenta))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "mx.com.tsys.ws.entity.EstadoCuentaEntity[ idEstadoCuenta=" + idEstadoCuenta + " ]";
    }
    
}
