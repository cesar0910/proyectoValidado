/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.com.tsys.ecd.service.rest;

import java.util.Date;
import javax.servlet.http.HttpServletRequest;
import mx.com.tsys.ecd.common.CommonUtils;
import mx.com.tsys.ecd.common.Constantes;
import mx.com.tsys.ecd.common.StackTraceUtil;
import mx.com.tsys.ecd.entity.CatalogoAccionEntity;
import mx.com.tsys.ecd.entity.EstadoCuentaEntity;
import mx.com.tsys.ecd.entity.TarjetaHabienteEntity;
import mx.com.tsys.ecd.exception.InternalServerErrorExcepcion;
import mx.com.tsys.ecd.exception.InvalidInputDataException;
import mx.com.tsys.ecd.exception.UnauthorizedException;
import mx.com.tsys.ecd.repository.BitacoraRepository;
import mx.com.tsys.ecd.repository.CatalogoAccionRepository;
import mx.com.tsys.ecd.repository.EstadoCuentaRepository;
import mx.com.tsys.ecd.repository.TarjetaHabienteRepository;
import mx.com.tsys.ecd.util.DateUtil;
import mx.com.tsys.ecd.util.FileFromByteUtil;
import org.apache.logging.log4j.LogManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * Clase que expone los servicios Rest
 *
 * @since septiembre 2015
 * @version 1.0
 * @author Said Guerrero
 */
@RestController
@RequestMapping("/rest")
public class DescargaEstadoCuentaPDFRest {

    //Lleva la bitacora de logs segun la configuracion del archivo log4j2.xml
    private static final org.apache.logging.log4j.Logger log = LogManager.getLogger(DescargaEstadoCuentaPDFRest.class.getName());

    @Autowired
    private EstadoCuentaRepository estadoCuentaRepository;

    @Autowired
    private TarjetaHabienteRepository tarjetaHabienteRepository;

    @Autowired
    private CatalogoAccionRepository catalogoAccionRepository;

    @Autowired
    private BitacoraRepository bitacoraRepository;

    /**
     * servicio que descarga el estado de cuenta en formato PDf
     * a partir de numero de cuenta y fecha corte
     * @param noCuenta
     * @param fechaCorte
     * @return
     */
    @RequestMapping(value = "/dsc/pdf/{noCuenta}/{fechaCorte}", method = RequestMethod.GET)
    @ResponseBody
    public ResponseEntity<byte[]> descargaEstadoCuentaPdf(@PathVariable("noCuenta") String noCuenta, @PathVariable("fechaCorte") String fechaCorte, HttpServletRequest request) {
        boolean success = false;
        String mensaje = "OK";
        ResponseEntity<byte[]> response = null;
        try {
            log.info("Solicitud descarga de estado de cuenta pdf...");
            if (CommonUtils.isEmpty(noCuenta) || CommonUtils.isEmpty(fechaCorte)) {
                log.info("no Cuenta/fecha corte is null.");
                mensaje = "no Cuenta/fecha corte is null.";
                throw new InvalidInputDataException("no Cuenta/fecha corte is null.");
            } else {
                success = true;
                Date fecha = DateUtil.parseDate(fechaCorte, Constantes.FECHA_FORMATO_DDMMYYYY);
                EstadoCuentaEntity estadoCuentaEntity = estadoCuentaRepository.findByNoCuentaAndFechaCorte(noCuenta, fecha);

                if (estadoCuentaEntity != null) {
                    byte[] contents = estadoCuentaEntity.getPdf();
                    //se crea el archivo 
                    response = FileFromByteUtil.creaArchivo(contents, Constantes.TIPO_ARCHIVO_PDF, "estadoCuenta.pdf");
                    mensaje = "Se descargo exitosamente el Html";
                } else {
                    mensaje = "no se encontro estado de cuenta";
                }
            }
            return response;
        } catch (InvalidInputDataException e) {
            log.error(StackTraceUtil.getStackTrace(e));
            mensaje = e.getMessage();
            throw new InvalidInputDataException(e.getMessage());
        } catch (UnauthorizedException e) {
            log.error(StackTraceUtil.getStackTrace(e));
            mensaje = e.getMessage();
            throw new UnauthorizedException(e.getMessage());
        } catch (Exception e) {
            log.error(StackTraceUtil.getStackTrace(e));
            mensaje = "Se genero un error interno.";
            throw new InternalServerErrorExcepcion("Se genero un error interno.");
        } finally {
            TarjetaHabienteEntity tarjetaHabienteEntity = (CommonUtils.isEmpty(noCuenta))
                    ? null : tarjetaHabienteRepository.findOne(noCuenta);
            CatalogoAccionEntity catalogoAccionEntity = catalogoAccionRepository.findOne(Constantes.ID_ACCION_DSC_PDF);
            bitacoraRepository.guardaBitacora(tarjetaHabienteEntity, catalogoAccionEntity, Constantes.CODIGO_ERROR, mensaje, request);

        }

    }
}
