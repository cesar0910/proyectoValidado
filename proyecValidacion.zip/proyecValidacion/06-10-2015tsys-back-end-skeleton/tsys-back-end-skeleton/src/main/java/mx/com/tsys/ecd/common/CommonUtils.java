/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.com.tsys.ecd.common;

/**
 * Clase que contiene metodos comunes de utileria
 *
 * @author Viera Rebolledo Jose B. - jviera.dev@gmail.com
 */
public final class CommonUtils {

    /**
     * Valida si el valor dado es nulo o se encuentra vacio
     * @param value
     * @return 
     */
    public static boolean isEmpty(String value) {
        if (null == value) {
            return true;
        }

        return value.trim().length() == 0;
    }

}
