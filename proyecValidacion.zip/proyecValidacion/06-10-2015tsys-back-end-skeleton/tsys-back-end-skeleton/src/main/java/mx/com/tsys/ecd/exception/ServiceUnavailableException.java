/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.com.tsys.ecd.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Servicio que cacha y trata las excepciones generadas al solicitar un servicio
 * que no se encuentra disponible.
 * @author Viera Rebolledo Jose B.  -   jviera.dev@gmail.com
 * @since Julio 2015
 * @version 1.0
 */
@ResponseStatus(value = HttpStatus.SERVICE_UNAVAILABLE, reason = "Por el momento el servicio no se encuentra disponible.")
public class ServiceUnavailableException extends RuntimeException {

    public ServiceUnavailableException() {
    }

    public ServiceUnavailableException(String message) {
        super(message);
    }

    public ServiceUnavailableException(String message, Throwable cause) {
        super(message, cause);
    }

    public ServiceUnavailableException(Throwable cause) {
        super(cause);
    }
    
}
