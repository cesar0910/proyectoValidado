/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.com.tsys.ecd.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import javax.mail.internet.ParseException;
import mx.com.tsys.ecd.common.CommonUtils;

/*** Esta clase contie metodos estaticos para manipulacion de fechas
 * a lo largo de la aplicacion, tales como formateo, parseo y transformacion
 * @since 04/09/2015
 * @version 1.0
 * @author Said Guerrero
 */
public class DateUtil {

    /**
     * Construye una fecha en base a un String y un formato o patron
     * @param value la cadena que representa la fecha
     * @param pattern patron/formato destino
     * @return un String transformado como instancia de Date
     * @throws ParseException
     */
    public static Date parseDate(String value, String pattern) throws ParseException, java.text.ParseException {
        if (CommonUtils.isEmpty(value)) {
            return null;
        }
        SimpleDateFormat format = new SimpleDateFormat(pattern);
        Date tempDate = format.parse(value);
        return new java.util.Date(tempDate.getTime());
    }
}
