package mx.com.tsys.ecd.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Clase que cacha y trata las excepciones generadas por ingresar valores 
 * incorrectos en los parametros de entrada.
 * @author Viera Rebolledo Jose B.  -   jviera.dev@gmail.com
 * @since Julio 2015
 * @version 1.0
 */
@ResponseStatus(value = HttpStatus.BAD_REQUEST, reason = "Los valores de los parametros de entrada son incorrectos.")
public class InvalidInputDataException extends RuntimeException {

    public InvalidInputDataException() {
    }

    public InvalidInputDataException(String message) {
        super(message);
    }

    public InvalidInputDataException(String message, Throwable cause) {
        super(message, cause);
    }

    public InvalidInputDataException(Throwable cause) {
        super(cause);
    }

}
