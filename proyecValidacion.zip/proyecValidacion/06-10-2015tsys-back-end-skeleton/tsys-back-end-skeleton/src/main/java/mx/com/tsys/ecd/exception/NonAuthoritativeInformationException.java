/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.com.tsys.ecd.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Clase que cacha y trata las excepciones generadas por solicitud de informacion no autorizada
 * @author Viera Rebolledo Jose B.  -   jviera.dev@gmail.com
 * @since Julio 2015
 * @version 1.0
 */
@ResponseStatus(value = HttpStatus.NON_AUTHORITATIVE_INFORMATION, reason = "No cuenta con autorizacion para visualizar la informacion solicitada.")
public class NonAuthoritativeInformationException extends RuntimeException {

    public NonAuthoritativeInformationException() {
    }
    
    public NonAuthoritativeInformationException(String message) {
        super(message);
    }

    public NonAuthoritativeInformationException(String message, Throwable cause) {
        super(message, cause);
    }

    public NonAuthoritativeInformationException(Throwable cause) {
        super(cause);
    }  
    
}
