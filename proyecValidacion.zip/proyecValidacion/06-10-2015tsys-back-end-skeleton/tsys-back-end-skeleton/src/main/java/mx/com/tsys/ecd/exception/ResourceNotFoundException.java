package mx.com.tsys.ecd.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Clase que cacha y trata las excepciones generadas cuando algun recurso solicitado
 * no se encuentra disponible.
 * @author Viera Rebolledo Jose B.
 * @since Julio 2015
 * @version 1.0
 */
@ResponseStatus(value = HttpStatus.NOT_FOUND, reason = "El recurso no se encuentra disponible.")
public class ResourceNotFoundException extends RuntimeException {

    public ResourceNotFoundException() {
    }

    public ResourceNotFoundException(String message) {
        super(message);
    }

    public ResourceNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }

    public ResourceNotFoundException(Throwable cause) {
        super(cause);
    }    

}
